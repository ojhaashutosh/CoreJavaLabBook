package com.cg.eis.pl;
import com.capg.corejava.lab7.EmployeeService;
import java.util.Scanner;


public class EmployeMainController {
	public static void main(String[] args) {

	int empId=0;
	String empname=null;
	double salary=0;
	String designnation=null;
	String insuranceScheme=" ";
	 
	Scanner sc=new Scanner(System.in);
	System.out.println("enter no of employee:");
	int n=sc.nextInt();
	for(int i=0;i<n;i++)
	{
	System.out.println("Enter Employee ID :");
	empId=sc.nextInt();
	
	System.out.println("Enter Employee Name :");
	 
     empname=sc.next();
	
	System.out.println("Enter Employee Salary :");
	
	salary=sc.nextDouble();
	
	System.out.println("Enter Employee Designation :");
	
	 designnation=sc.next();
	
	//System.out.println("Enter insuranceScheme :");
	//insuranceScheme=sc.next();
	 
	 EmployeeService emps= new EmployeeService();
	 int retval= emps.addEmployeeService(empId, empname,salary,designnation);
	System.out.println("Main controller Return value is : "+retval);
	}
	
}
}
