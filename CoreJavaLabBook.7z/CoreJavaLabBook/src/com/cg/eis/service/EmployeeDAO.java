package com.cg.eis.service;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.eis.bean.Employee;

public class EmployeeDAO {
	
	public int addEmployee(Employee employeebean)
	{
		ArrayList emplist= new ArrayList();
		HashMap hm=new HashMap();
		emplist.add(employeebean.getempId());
	 emplist.add(employeebean.getempname());
	 emplist.add(employeebean.getsalary());
	 emplist.add(employeebean.getdesignation());
	 emplist.add(employeebean.getinsuranceScheme());

	 System.out.println("Employee list :"+emplist );
		
	 
	 System.out.println("employee Id :"+employeebean.getempId());
		System.out.println("name:"+employeebean.getempname());
		System.out.println("salary:"+employeebean.getsalary());
		System.out.println("designation :"+employeebean.getdesignation());
		System.out.println("insurance scheme :"+employeebean.getinsuranceScheme());
		
	 
		return 1;
	}

}