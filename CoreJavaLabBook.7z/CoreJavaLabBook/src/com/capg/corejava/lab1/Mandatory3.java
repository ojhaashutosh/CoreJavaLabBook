package com.capg.corejava.lab1;

import java.util.Scanner;

public class Mandatory3 {
	
	public boolean checkNumber(int n)
	{
		boolean t=false;
		for(int i=n;i>0;i/=10)
		{
			if(i%10 >= (i%100)/10)
				t=true;
			else
			{
				t=false;
				break;
			}
		}
		return t;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		System.out.println("Enter the number");
		int n= scr.nextInt();
		Mandatory3 m1= new Mandatory3();
		if(m1.checkNumber(n))
		 System.out.println(n+" is an increasing number");
		else
			System.out.println(n+" is not an increasing number");
		scr.close();

	}

}
