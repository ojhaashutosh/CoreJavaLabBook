package com.capg.corejava.lab1;

import java.util.Scanner;

public class Mandatory2 {
	
	public int calculateDifference(int n)
	{
		int sum1=0, sum2=0;
		for(int i=1;i<=n;i++)
		{
			sum1+=(i*i);
			sum2+=i;
		}
		sum2=sum2*sum2;
		return sum1-sum2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		System.out.println("Enter the number");
		int n= scr.nextInt();
		Mandatory2 m1= new Mandatory2();
		System.out.println("Difference = "+m1.calculateDifference(n));
		scr.close();

	}

}
