package com.capg.corejava.lab7;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeDAO;

public class EmployeeService {
	
	public int  addEmployeeService(int empId,String empname,double salary,String designation)
	{
	   String insuranceScheme=" ";
	   
	   if(salary>5000 && salary<20000)
	{
		   insuranceScheme="Scheme C";
		   }
	   else if (salary>=20000 && salary<40000)
		{
			   insuranceScheme="Scheme B";
			   }
	   else if (salary>=40000)
		{
			   insuranceScheme="Schem A";
			   }
	   else 
		{
		   insuranceScheme="NO Scheme";
		   }
	   Employee employeebean=new Employee();
	   employeebean.setempId(empId);
	   employeebean. setsalary(salary) ;
	   employeebean.setempname(empname);
	   employeebean.setdesignation(designation);
	  employeebean.setinsuranceScheme(insuranceScheme);
	  
	   EmployeeDAO empdao= new EmployeeDAO();
	  int k=empdao.addEmployee(employeebean);

	return k;
}
}