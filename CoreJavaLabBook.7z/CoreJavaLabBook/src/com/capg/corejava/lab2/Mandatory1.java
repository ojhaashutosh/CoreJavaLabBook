package com.capg.corejava.lab2;

import java.util.Scanner;
public class Mandatory1 {
	
	public int getSecondSmallest(int [] arr)
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1; j<arr.length;j++)
			{
				if(arr[i]>arr[j])
				{
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		
		return arr[1];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		int []arr;
		int n;
		System.out.println("enter no of elements");
		n=scr.nextInt();
		arr= new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter element for arr["+i+"]");
			arr[i]=scr.nextInt();
		}
		Mandatory1 m1= new Mandatory1();
		System.out.println("Second smallest element:"+m1.getSecondSmallest(arr));
		scr.close();

	}

}
