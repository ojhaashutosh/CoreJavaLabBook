package com.capg.corejava.lab2;

import java.util.Scanner;
public class Mandatory2 {
	
	public String[] sortString(String [] arr)
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1; j<arr.length;j++)
			{
				if(arr[i].compareTo(arr[j])>1)
				{
					String temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		
		return arr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		String []arr;
		int n;
		System.out.println("enter no of elements");
		n=scr.nextInt();
		scr.nextLine();
		arr= new String[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter element for arr["+i+"]");
			arr[i]=scr.next();
		}
		Mandatory2 m1= new Mandatory2();
		String [] ar= m1.sortString(arr);
		System.out.println("after Sorting");
		for(int i=0;i<n;i++)
		{
			int len;
			if(n%2==0)
				len=n/2;
			else
				len=n/2+1;
			if(i<len)
			{
			System.out.print(ar[i].toUpperCase()+ " ");
			}
			else
			System.out.print(ar[i].toLowerCase()+ " ");
		}
		System.out.println();
		
		scr.close();

	}

}
