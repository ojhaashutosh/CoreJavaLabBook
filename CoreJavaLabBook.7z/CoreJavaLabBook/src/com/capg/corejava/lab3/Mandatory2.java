package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory2 {
	
	public String getImage(String s)
	{
		StringBuffer st=new StringBuffer(s);
		st.reverse();
		s+="|";
		s+=st.toString();
		return s;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		String s;
		System.out.println("Enter the string");
		s=scr.nextLine();
		Mandatory2 m2=new Mandatory2();
		System.out.println("Mirror Image: ");
		System.out.println(m2.getImage(s));
		scr.close();
		

	}

}
