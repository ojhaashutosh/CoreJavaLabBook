package com.capg.corejava.lab5;
import java.util.*;

class EmployeeException extends Exception
{
	EmployeeException(String mess)
	{
		System.out.println(mess+" than expected");
	}
}

public class Mandatory3 {
	
	
	public void empSal(int sal) throws Exception
	{
		if(sal<3000)
			throw new EmployeeException("Below");
		
		else
			System.out.println("Accepted");
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sal;
		System.out.println("Enter the salary");
		sal=sc.nextInt();
		
		try {
			Mandatory3 ud=new Mandatory3();
		ud.empSal(sal);
		}
		catch (Exception e)
		{
			System.out.println("I can handle exception"+e);
		}
      sc.close();
	}

}


