package com.capg.corejava.lab5;
import java.util.*;

class AgeNotSupportException extends Exception
{
	AgeNotSupportException(String mess)
	{
		System.out.println("Your age is "+mess);
	}
}

public class Mandatory1 {
	
	
	public void myData(int age) throws Exception
	{
		if(age<15)
			throw new AgeNotSupportException("Less than 15");
		else
			System.out.println("Eligible");
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int age;
		System.out.println("Enter the age");
		age=sc.nextInt();
		
		
		try {
			Mandatory1 ud=new Mandatory1();
		ud.myData(age);
		}
		catch (Exception e)
		{
			System.out.println("I can handle exception"+e);
		}
		sc.close();

	}

}


